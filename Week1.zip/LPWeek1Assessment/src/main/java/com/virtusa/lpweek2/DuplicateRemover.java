package com.virtusa.lpweek2;

import java.util.LinkedHashSet;
import java.util.Set;

public class DuplicateRemover {

	
	public static void main(String[] args) {
         String str = "jeeva";
         Set<Character> remover = new LinkedHashSet<Character>();
         for(int index1=0;index1<str.length();index1++)
         {
        	 remover.add(str.charAt(index1));
         }
         
         System.out.println(remover.toString());
         
         
	}

}
