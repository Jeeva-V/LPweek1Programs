package com.virtusa.lpweek2;

public class ShortNameMaker {

	public static void main(String[] args) {
		   
		   StringBuilder sb= new StringBuilder("John F. Kennedy");
		   int length =sb.length(),startIndex=0,endIndex = sb.indexOf(" ", 0);
		   
		  do
		   {	
               System.out.print(sb.substring(startIndex, endIndex).charAt(0)); 
               startIndex= endIndex+1;
               endIndex = sb.indexOf(" ", startIndex);
 	       
		   }
		   while(endIndex<sb.length() && endIndex!=-1);
		   
		  System.out.print(sb.substring(startIndex,length-1).charAt(0));
           
	}

}
