package com.virtusa.lpweek2;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Collections;
import java.util.List;


public class sortALinesOfTextFile {
     void sortTextFile(String FileName, String toFileName) throws IOException
     {
    	 Path path = Paths.get(FileName);
    	 List<String> lines = Files.readAllLines(path);
    	 Collections.sort(lines);
    	 
    	 Path toPath = Paths.get(toFileName);
    	 Files.write(toPath, lines);
    	 
     }
	
	public static void main(String[] args) throws IOException {
		new sortALinesOfTextFile().sortTextFile("D:\\IOPratice\\demo.txt" , "D:\\IOPratice\\sortedDemo.txt");
        System.out.println("Sorting Completed");
	}

}
