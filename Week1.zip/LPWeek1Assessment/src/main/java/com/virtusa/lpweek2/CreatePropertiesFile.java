package com.virtusa.lpweek2;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.Scanner;

public class CreatePropertiesFile {

	public static void main(String[] args) {
         Scanner sc = new Scanner(System.in);
         Properties property = new Properties();
         for(int index=0;index<2;index++)
         {
        	 property.setProperty(sc.next(), sc.next());
         }
         try
         {
        	 property.store(new FileOutputStream("details.properties"), null);
         } catch(FileNotFoundException e)
         {
        	 e.printStackTrace();
         } catch(IOException e)
         {
        	 e.printStackTrace();
         }
         

	}

}
