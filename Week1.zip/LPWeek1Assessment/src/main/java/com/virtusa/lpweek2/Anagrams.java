package com.virtusa.lpweek2;

import java.util.Arrays;

public class Anagrams {
        
	public static void anagramChecker(String s1, String s2, String s3)
	{
		s1 = s1.replaceAll(" ", ""); 
        s2 = s2.replaceAll(" ", "");
        s3 = s3.replaceAll(" ", "");
        boolean status = true;
 
        if(s1.length() != s2.length() || s1.length() != s3.length())
        {
 
        	System.out.println(s1+","+s2+" and "+s3+" are not anagrams");
        }
        else
        {
            char[] s1Array = s1.toLowerCase().toCharArray();
            char[] s2Array = s2.toLowerCase().toCharArray();
            char[] s3Array = s3.toLowerCase().toCharArray();
   
 
            Arrays.sort(s1Array);
            Arrays.sort(s2Array);
            Arrays.sort(s3Array);
             
            
            if( Arrays.equals(s1Array, s2Array))
            {
            	if( Arrays.equals(s1Array, s2Array))
            	{
            		System.out.println(s1+","+s2+" and "+s3+" are anagrams");
            	}
            }
            else
            {
            	System.out.println(s1+","+s2+" and "+s3+" not are anagrams");
            }
	    }
	}
	
	public static void main(String[] args) {
         
		anagramChecker("abcd", "bdca", "cad b");
	}

}
