package com.virtusa.lpweek2;

import java.util.Scanner;

class Basket extends Thread{
	static int bulb=0;
    public void run()
    {
        if(Thread.currentThread().getName().equals("fill"))
        {
          System.out.println("going to fill");  
         for(int i=1;i<5;i++)
           {
               bulb++;
               System.out.println(bulb);  
           }
          System.out.println("filling completed ");  
        }
        else
        {
        System.out.println("going to pack");  
             for(int i=1;i<5;i++)
           {
                bulb--;
             System.out.println(bulb);  
         }    
        System.out.println("packing completed ");  
    }
    }
}


public class BasketFilling {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int key;
		while(true)
		{
		    System.out.println("If you want  to stop the process, press 0.");
		    key = scanner.nextInt();
		    if(key==0)
		    {
		        break;
		    }
		Basket fill=new Basket();
		fill.setName("fill");
		Basket pack=new Basket();
		pack.setName("pack");
		    fill.start();
		    try {
		       fill.join();
		    } catch(Exception e) {
		    }
		    pack.start();
		    try {
		       pack.join();
		    } catch(Exception e) {
		    }
		}
	}

}
