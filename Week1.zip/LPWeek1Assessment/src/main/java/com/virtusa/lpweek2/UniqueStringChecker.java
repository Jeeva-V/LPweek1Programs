package com.virtusa.lpweek2;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class UniqueStringChecker {

	public static void main(String[] args) {
             
		Scanner scanner = new Scanner(System.in);
		String str = scanner.next();
		boolean status = true;
	    Map<Character,Integer> map = new HashMap<Character,Integer>();
	    
	    for(int i=0;i<str.length();i++)
	    {
	    	if(map.containsKey(str.charAt(i)))
	    	{
	    		int c= map.get(str.charAt(i));
	    		map.put(str.charAt(i), ++c);
	    	}
	    	else
	    	{
	    		map.put(str.charAt(i), 1);
	    	}
	    }
	    
	    for(Character ch : map.keySet())
	    {
	    	if(map.get(ch)!=1)
	    	status= false;
	    }
	    
	    if(status)
	    System.out.println("The String is Unique");
	    else
	    System.out.println("The String is not Unique");	
	    	

	}

}
