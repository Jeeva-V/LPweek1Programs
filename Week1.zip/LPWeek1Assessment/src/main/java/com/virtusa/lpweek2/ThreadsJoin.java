package com.virtusa.lpweek2;

class ThreadJoining extends Thread
{
	public void run()
	{
		for (int i = 0; i < 2; i++)
		{
			try
			{
			Thread.sleep(500);
			System.out.println("Current Thread: "+ Thread.currentThread().getName());
			}
			catch(Exception ex)
			{
			System.out.println("Exception has" +" been caught" + ex);
			}
			System.out.println(i);
		}
	}
}

public class ThreadsJoin {

	public static void main(String[] args) {
          
		ThreadJoining B = new ThreadJoining();
		ThreadJoining C = new ThreadJoining();
		ThreadJoining D = new ThreadJoining();
		B.start();
		try
		{
		B.join();
		C.start();
		D.start();
		}
		catch(Exception ex)
		{
		System.out.println("Exception has " +"been caught" + ex);
		}
		
	}

}
