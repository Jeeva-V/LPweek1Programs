package com.virtusa.lpweek2;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class UpdateFile {

	public static void main(String[] args) throws IOException {
         FileReader reader = new FileReader("D:\\IOPratice\\demo.txt");
         BufferedReader input = new BufferedReader(reader);
         String str= input.readLine();
         String str2 = str.subSequence(0, 4)+ "are "+str.substring(4);
         input.close();
         FileWriter writer = new FileWriter("D:\\IOPratice\\Updatedemo.txt");
         writer.write(str2);
         writer.close();
         
	}

}
