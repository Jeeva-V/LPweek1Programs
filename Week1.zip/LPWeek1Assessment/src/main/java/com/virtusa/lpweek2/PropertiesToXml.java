package com.virtusa.lpweek2;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.InvalidPropertiesFormatException;
import java.util.Properties;


public class PropertiesToXml {

	public static void main(String[] args) throws
    InvalidPropertiesFormatException, IOException {
		String inPropertiesFile = "application.properties";
        String outXmlFile = "applicationProperties.xml";
 
        InputStream is = new FileInputStream(inPropertiesFile); 
        OutputStream os = new FileOutputStream(outXmlFile);
         
        Properties props = new Properties();
        props.load(is);
         
        props.storeToXML(os, "application.properties","UTF-8");

	}

}
