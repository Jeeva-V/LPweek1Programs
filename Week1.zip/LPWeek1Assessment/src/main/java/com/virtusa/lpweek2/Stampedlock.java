package com.virtusa.lpweek2;
import java.util.concurrent.locks.*;



class MyThread extends Thread
{ 
   StampedLock lock = null;    
   public MyThread(String name, StampedLock lock)    
   { 
     super(name); 
     this.lock=lock;    
    }     
    public void run()    
    {     
       long stamp = lock.tryWriteLock();   
       System.out.println(Thread.currentThread().getName()+" Got the writeLock " + stamp);
       try     
       {      
         Thread.sleep(5000);     
       }     
       catch(InterruptedException e){}     
       try
       {
        lock.unlock(stamp);    
       }
       catch(IllegalMonitorStateException e)
       {
          System.out.println(Thread.currentThread().getName()+" "+e+" did not get the lock");    
       }
       finally
       {
          System.out.println(Thread.currentThread().getName()+" Finished");    
       }
     }
}

public class Stampedlock {

	public static void main(String[] args) {
		StampedLock lock = new StampedLock();   
	      MyThread[] t = new MyThread[5];  
	      for(int i=0; i < 5; i++)  
	      {   
	        t[i] = new MyThread("t"+i, lock);  
	      }  
	      for(int i=0; i< 5; i++)  
	      {   
	         t[i].start();  
	      } 

	}

}
