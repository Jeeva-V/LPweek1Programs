package com.virtusa.lp;

import java.util.Scanner;


interface payment
{
	public boolean pinVerification(double pin);
	public void PaymentDetails(String Name, String accNo , String IFSCcode );
}


class PayementCustomer implements payment
{

	private double pin=1234;
	private String name;
	private String accNo;
	private String IFSCcode;
	public boolean pinVerification(double pin) {
		if(this.pin == pin)
			return true;
		else
			return false;
		
	}

	public void PaymentDetails(String name, String accNo , String IFSCcode ) {
		this.name = name;
		this.accNo = accNo;
		this.IFSCcode =IFSCcode;
	}

	public String getName() {
		return name;
	}

	public String getAccNo() {
		return accNo;
	}

	public String getIFSCcode() {
		return IFSCcode;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setAccNo(String accNo) {
		this.accNo = accNo;
	}

	public void setIFSCcode(String iFSCcode) {
		IFSCcode = iFSCcode;
	}
	
}



public class PaymentProcess {

	public static void main(String[] args) {
           Scanner scanner = new Scanner(System.in);  
           PayementCustomer c =new PayementCustomer();
           double pin = scanner.nextDouble();
           if(c.pinVerification(pin))
              {
        	      c.PaymentDetails("Jeeva", "123456789", "ABC00567");   
        	      System.out.print("Transaction Sucess");
        	  }
           else
           {
        	   System.out.print("Invalid Pin");
           }
	}

}
