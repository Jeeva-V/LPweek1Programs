package com.virtusa.lp;

public class CylinderFilling {

	public static void main(String[] args) {
		       double volume = 3.14 * 2.5*2.5 *20;
               System.out.println("Volume of cylinder:- " + volume  +"cubic feet");
               System.out.printf("\nRate of liquid flow needed to fill in one hour:- %.3f litre/second" , volume/(60.00*60.00) );
               System.out.printf("\nRate of liquid flow needed to fill in two hour:- %.3f litre/second" , volume/(60.00*60.00*2.00)   );
               System.out.printf("\nRate of liquid flow needed to fill in three hour:- %.3f litre/second" , volume/(60.00*60.00*3.00) );
               System.out.printf("\nRate of liquid flow needed to fill in four hour:- %.3f litre/second" , volume/(60.00*60.00*4.00)  );
	}

}
