package com.virtusa.lp;

class StudentDetails
{
	private String name;
    private int rollNo;
	private int marks;
	public StudentDetails(String name, int rollNo, int marks) {
		super();
		this.name = name;
		this.rollNo = rollNo;
		this.marks = marks;
	}
	public String getName() {
		return name;
	}
	public int getRollNo() {
		return rollNo;
	}
	public int getMarks() {
		return marks;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setRollNo(int rollNo) {
		this.rollNo = rollNo;
	}
	public void setMarks(int marks) {
		this.marks = marks;
	}
	@Override
	public String toString() {
		return "StudentDetails [name=" + name + ", rollNo=" + rollNo + ", marks=" + marks + "]";
	}
	
	
}


public class Encapsulation {

	public static void main(String[] args) {
		StudentDetails student =  new StudentDetails("Jeeva", 1234, 450);

	}

}
