package com.virtusa.lp;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class AscendingDescending {

	public static void main(String[] args) {
         List<Integer> myList = new ArrayList<Integer>();
         myList.add(50);
         myList.add(29);
         myList.add(35);
         myList.add(11);
         myList.add(78);
         myList.add(64);
         myList.add(89);
         myList.add(67);
         
         Collections.sort (myList.subList(0, 4)) ;
         Collections.sort(myList.subList(4,8),Collections.reverseOrder());
         
         for(Integer N:myList)
         {
        	 System.out.println(N);
         }
         
	}

}
