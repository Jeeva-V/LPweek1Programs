package com.virtusa.lp;

import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ScientificCalculation {

	static Logger logger = Logger.getLogger(ScientificCalculation.class.getName());
	static Scanner scanner = new Scanner(System.in);
	public static void main(String[] args) {
	    logger.log(Level.INFO,"Select the operation \n1.Tan \n2.cos \n3.sec \n4.Square Root \n5.Cube Root");
		
	    int key =scanner.nextInt();
		switch(key)
		{
		case 1:
			tan();
			break;
		case 2:
			cos();
			break;
		case 3:
		    sec();
		    break;
		case 4:
		    squareRoot();
		    break;
		case 5:
		     cubeRoot();
		     break;
		}

	}
	private static void cubeRoot() {
		logger.log(Level.INFO,"Enter the Degree:");
		double value = scanner.nextDouble();
		logger.log(Level.INFO, "Result:-"+ Math.cbrt(value));
		
	}
	private static void squareRoot() {
		logger.log(Level.INFO,"Enter the value :");
		double value = scanner.nextDouble();
		logger.log(Level.INFO, "Result:-"+ Math.sqrt(value));
		
	}
	private static void sec() {
		logger.log(Level.INFO,"Enter the Degree :");
		double value = scanner.nextDouble();
		logger.log(Level.INFO, "Result:-"+ 1.00/Math.cos(value));
		
	}
	private static void cos() {
		logger.log(Level.INFO,"Enter the Degree :");
		double value = scanner.nextDouble();
		logger.log(Level.INFO, "Result:-"+Math.cos(value));
		
	}
	private static void tan() {
		logger.log(Level.INFO,"Enter the Degree :");
		double value = scanner.nextDouble();
		logger.log(Level.INFO, "Result:-"+Math.tan(value));
		
	}

}
