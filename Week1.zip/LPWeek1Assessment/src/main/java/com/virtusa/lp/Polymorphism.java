package com.virtusa.lp;

class Addition
{
	int operation(int a,int b)
	{
		return a+b;
	}
	
	int operation(int a,int b,int c)
	{
		return a+b+c;
	}
	
}
class Subraction extends Addition
{
	int operation(int a,int b)
	{
		return a-b;
	}
	int operation(int a,int b,int c)
	{
		return (a-b)-c;
	}
	
}
class Multiplication extends Subraction
{
	int operation(int a,int b)
	{
		return a*b;
	}
	int operation(int a,int b,int c)
	{
		return a*b*c;
	}
}
class Division extends Multiplication
{
	int operation(int a,int b)
	{
		return a/b;
	}
	int opertion(int a,int b,int c)
	{
		return (a/b)/c;
	}
}



public class Polymorphism {

	public static void main(String[] args) {
		     Addition a= new Addition();
		     Subraction s= new Subraction();
		     Multiplication m = new Multiplication();
		     Division d =new Division();
             System.out.println(a.operation(2, 6));
             System.out.println(a.operation(2, 6, 5));
             System.out.println(s.operation(2, 6));
             System.out.println(m.operation(2, 6));
             System.out.println(d.operation(6, 3));

	}

}
