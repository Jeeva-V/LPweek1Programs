package com.virtusa.lp;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;


public class CurrencyConverter {
	static Logger logger = Logger.getLogger(CurrencyConverter.class.getName());
	static void operation(int key)
	{
		Logger logger = Logger.getLogger(CurrencyConverter.class.getName());
		Scanner sc = new Scanner(System.in); 
		
		switch (key)
		{
			case 1:
				{
					logger.log(Level.INFO,"Enter USD :-");
					double usd =sc.nextDouble();
			        logger.log(Level.INFO,"\nConverted USD :" + String.format("%.3f", usdToInr(usd)));
					break;
				}
			case 2:
				{
					logger.log(Level.INFO,"Enter INR :-");
					double inr =sc.nextDouble();
					logger.log(Level.INFO,"\nConverted USD : "+ String.format("%.3f", inrToUsd(inr)));
					break;
				}
			case 3:
				{
					logger.log(Level.INFO,"Enter MD :-");
					double md =sc.nextDouble();
					double usd1 = mdToUsd(md);
					logger.log(Level.INFO,"\nConverted EURO : " + String.format("%.3f", usdToEuro(usd1)));
					break;
				}
			case 4:
				{
					logger.log(Level.INFO,"Enter EURO :-");
					double euro =sc.nextDouble();
					double usd2 = euroToUsd(euro);
					logger.log(Level.INFO,"\nConverted MD :  " +String.format("%.3f", usdToMd(usd2)));
					break;
				}
			
			
			default:
				{
					
					break;
				}
			}
	}
	
	
	static double usdToInr(double usd)
	{
		return usd * 73.2355;
	}
	
	static double inrToUsd(double inr)
	{
		
		return inr * 0.0136546;
	}
	
	static double mdToUsd(double md)
	{
		return md * 0.108235;
	}
	
	static double usdToEuro(double usd)
	{
		return usd * 0.850663;
		
	}
	
	static double euroToUsd(double euro)
	{
		return euro * 1.17555;
	}
	
	static double usdToMd(double usd)
	{

		return usd *0.108281;
	}
	 
	public static void main(String[] args) {
         Scanner sc1 = new Scanner(System.in);
        while(true)
        {	
        	     logger.log(Level.INFO,"\nCurrency Converter.. \n 1. USD - INR \n 2. INR - USD \n 3. MD - EURO \n 4. EURO - MD ");
		
				int key= sc1.nextInt();
				
				if(key<=4)
				{
					operation(key);
				}
				else
				{
					break;
				}
                 
        }

	}

}
