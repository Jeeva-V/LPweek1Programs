package com.virtusa.lp;

class StudentInfo
{
	private String name;
	private int age;
	private int rollNo;
	public StudentInfo(String name, int age, int rollNo) {
		super();
		this.name = name;
		this.age = age;
		this.rollNo = rollNo;
	}
	@Override
	public String toString() {
		return "Student [name=" + name + ", age=" + age + ", rollNo=" + rollNo + "]";
	}
	
}


public class SallowCopy {

	public static void main(String[] args) {
		
		StudentInfo s1= new StudentInfo("Jeeva", 22, 41);
		StudentInfo s2=s1;
		System.out.println(s2.toString());

	}

}
