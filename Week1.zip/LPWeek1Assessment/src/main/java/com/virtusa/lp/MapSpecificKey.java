package com.virtusa.lp;

import java.util.HashMap;
import java.util.Map;

public class MapSpecificKey {

	public static void main(String[] args) {
		Map<Integer,String> map = new HashMap<Integer, String>();
		map.put(1, "Jeeva");
		map.put(2, "Santhose");
		map.put(3, "Vijay");
		map.put(4, "Kiruba");
		map.put(5, "Dharani");
		map.put(6,"Kavya" );
		
		System.out.println(map.containsKey(7));

	}

}
