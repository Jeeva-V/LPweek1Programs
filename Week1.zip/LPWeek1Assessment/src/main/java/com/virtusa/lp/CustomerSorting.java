package com.virtusa.lp;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

class Customer implements Comparable<Customer>
{
	String customerName;
	int age;
	int customerId;
	public Customer()
	{
	}
	
	public Customer(String customerName, int age, int customerId) {
		super();
		this.customerName = customerName;
		this.age = age;
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public int getAge() {
		return age;
	}

	public int compareTo(Customer o) {
		int compare = getCustomerName().compareTo(o.getCustomerName());
		if(compare ==0)
		{
			compare = Integer.compare(getAge(), o.getAge());
		}
		return compare;
	}

	@Override
	public String toString() {
		return "\n [customerName=" + customerName + ", age=" + age + ", customerId=" + customerId + "]";
	}

	
	 
	
}

public class CustomerSorting {

	public static void main(String[] args) {
		List<Customer> customerList =  new ArrayList();   
        Customer customer1 = new Customer("Jeeva" , 22 , 1);
        Customer customer2 = new Customer("Rajkumar" , 32 , 2);
        Customer customer3 = new Customer("Krathi" , 35 , 3);
        Customer customer4 = new Customer("Lovlin" , 31 , 4);
        Customer customer5 = new Customer("Yogapriya" , 34 , 1);
        Customer customer6 = new Customer("Rajkumar" , 35 , 2);
        
        customerList.add(customer1);
        customerList.add(customer2);
        customerList.add(customer3);
        customerList.add(customer4);
        customerList.add(customer5);
        customerList.add(customer6);
        
        Customer c = new Customer();
        Collections.sort(customerList);
        System.out.println(customerList);
        
        
	}


}
