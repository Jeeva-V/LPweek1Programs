package com.virtusa.lp;

import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class TaxCalculator {
	static Logger logger = Logger.getLogger(CurrencyConverter.class.getName());
	public static void main(String[] args) {
                 Scanner scanner = new Scanner(System.in);
                 
                 logger.log(Level.INFO, "Enter Employee's Annual salary :-");
                 
                 double salaryOfEmployee = scanner.nextDouble();
                 
                 logger.log(Level.SEVERE, "Enter Employee's Gender:-");
                 
                 String gender = scanner.next();
                 
                 //logger.log(Level.INFO, "Payable Tax: "+taxCalculation(salaryOfEmployee,gender));
                 
                 String.format("Payable Tax: %f ",taxCalculation(salaryOfEmployee,gender));

	}
	private static double taxCalculation(double salaryOfEmployee,String gender) {
		
		double tax;
		if(salaryOfEmployee<150000)
		{
			tax= 0.000000;
		}
		else if(salaryOfEmployee>150000 && salaryOfEmployee<= 1000000)
		{
			tax= salaryOfEmployee * 0.1;
		}
		else if(salaryOfEmployee>1000000 && salaryOfEmployee<= 1500000)
		{
			tax= salaryOfEmployee * 0.2;
		}
		else if(salaryOfEmployee>1500000 && salaryOfEmployee< 3000000)
		{
			tax= salaryOfEmployee * 0.35;
		}
		
		else 
		{
			tax= salaryOfEmployee * 0.4;
		}
		
		
		if(gender.equals("female"))
		{
			return tax-2000.00;
		}
		else
		{
			return tax;
		}
	}

}
