package com.virtusa.lp;

import java.util.Scanner;

interface paymentMethod
{
	public void creditCardPayment();
	public void netBankingPayment();
	public void walletPayemnt();
	public void UpiPayment();
    	
}

class PaymentMethods implements paymentMethod
{

	public void creditCardPayment() {
		System.out.println("Enter the card Details");
	}

	public void netBankingPayment() {
		System.out.println("Enter the Account Details");
	}

	public void walletPayemnt() {
		System.out.println("Enter the password");
	}

	public void UpiPayment() {
		System.out.println("Enter the account Details");
	}
	
}

public class CustomerPaymentGateway {
             public static void main(String[] args) {
              Scanner scanner = new Scanner(System.in); 	 
	          System.out.println("Select the mode of payment\n1.Credit Card\n2.Net Banking\n3.Wallet\n4.UPI");
	          int key = scanner.nextInt();
	          PaymentMethods payment = new PaymentMethods();
	          switch(key)
	          {
	            case 1:
	            {
	            	payment.creditCardPayment();
	            	break;
	            }
	            case 2:
	            {
	            	payment.netBankingPayment();
	            	break;
	            }
	            case 3:
	            {
	            	payment.walletPayemnt();
	            	break;
	            }
	            case 4:
	            {
	            	payment.UpiPayment();
	            	break;
	            } 
	          }
	          
            	 
}
}
